export const productResearchAgentCode = `#!/usr/bin/env python3
"""
AffiliAgent Hub - Amazon Product Research Agent

This script uses Amazon's Product Advertising API to find profitable
products for Amazon affiliate marketing based on specified criteria.

Requirements:
- Python 3.6+
- Amazon Product Advertising API credentials
- Required packages: requests, pandas, boto3

Setup:
1. Install required packages: pip install requests pandas boto3
2. Set up Amazon Product Advertising API credentials
3. Configure the search parameters below

Usage:
python product_research_agent.py
"""

import os
import json
import time
import datetime
import hmac
import hashlib
import base64
import requests
import pandas as pd
from urllib.parse import quote
from typing import Dict, List, Any, Optional, Tuple

class AmazonProductResearchAgent:
    """
    Agent for researching profitable Amazon products for affiliate marketing.
    Uses Amazon's Product Advertising API to find products based on various criteria.
    """
    
    def __init__(self, 
                 access_key: str, 
                 secret_key: str, 
                 partner_tag: str, 
                 region: str = 'us',
                 min_price: float = 20.0,
                 max_price: float = 200.0,
                 min_rating: float = 4.0,
                 min_reviews: int = 100):
        """
        Initialize the Amazon Product Research Agent.
        
        Args:
            access_key: Amazon Product Advertising API access key
            secret_key: Amazon Product Advertising API secret key
            partner_tag: Amazon Associate partner tag
            region: Amazon marketplace region (default: 'us')
            min_price: Minimum product price (default: 20.0)
            max_price: Maximum product price (default: 200.0)
            min_rating: Minimum product rating (default: 4.0)
            min_reviews: Minimum number of reviews (default: 100)
        """
        self.access_key = access_key
        self.secret_key = secret_key
        self.partner_tag = partner_tag
        self.region = region
        self.min_price = min_price
        self.max_price = max_price
        self.min_rating = min_rating
        self.min_reviews = min_reviews
        
        # API endpoint URLs by region
        self.endpoints = {
            'us': 'webservices.amazon.com',
            'uk': 'webservices.amazon.co.uk',
            'de': 'webservices.amazon.de',
            'fr': 'webservices.amazon.fr',
            'jp': 'webservices.amazon.co.jp',
            'ca': 'webservices.amazon.ca',
            'it': 'webservices.amazon.it',
            'es': 'webservices.amazon.es',
            'in': 'webservices.amazon.in',
        }
        
        # Commission rates by category (approximate, these vary)
        self.commission_rates = {
            'Amazon Devices': 4.0,
            'Automotive': 4.5,
            'Baby Products': 4.5,
            'Beauty': 6.0,
            'Books': 4.5,
            'Clothing': 7.0,
            'Electronics': 4.0,
            'Furniture': 8.0,
            'Garden': 3.0,
            'Grocery': 1.0,
            'Health & Personal Care': 4.5,
            'Home': 8.0,
            'Home Improvement': 3.0,
            'Kitchen': 8.0,
            'Office Products': 4.0,
            'Pet Products': 8.0,
            'Sports': 5.5,
            'Tools': 3.0,
            'Toys': 3.0,
            'Video Games': 1.0,
            'Default': 3.0,  # Default rate for unlisted categories
        }
        
        # Current date and time for request signing
        self.timestamp = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
        
    def sign_request(self, params: Dict[str, str]) -> str:
        """Generate signature for Amazon Product Advertising API request."""
        canonical_query_string = '&'.join(['{}={}'.format(k, quote(params[k], safe='')) for k in sorted(params)])
        
        string_to_sign = '\n'.join([
            'GET',
            self.endpoints[self.region],
            '/paapi5/searchitems',
            canonical_query_string
        ])
        
        signature = hmac.new(
            self.secret_key.encode('utf-8'),
            string_to_sign.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        return base64.b64encode(signature).decode('utf-8')
    
    def search_products(self, 
                        keywords: str, 
                        category: str = 'All', 
                        sort_by: str = 'Relevance',
                        limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for products using Amazon's Product Advertising API.
        
        Args:
            keywords: Search keywords
            category: Product category
            sort_by: Sort method (Relevance, Price:HighToLow, Price:LowToHigh, Rating, etc.)
            limit: Maximum number of results (max 10 per API call)
            
        Returns:
            List of product dictionaries
        """
        # Build the request parameters
        params = {
            'AccessKey': self.access_key,
            'Action': 'SearchItems',
            'Keywords': keywords,
            'Marketplace': self.endpoints[self.region],
            'PartnerTag': self.partner_tag,
            'PartnerType': 'Associates',
            'Service': 'ProductAdvertisingAPI',
            'Timestamp': self.timestamp,
        }
        
        # Add optional parameters
        if category != 'All':
            params['SearchIndex'] = category
            
        # Generate signature and add to parameters
        params['Signature'] = self.sign_request(params)
        
        # Build the request URL
        endpoint = f"https://{self.endpoints[self.region]}/paapi5/searchitems"
        
        try:
            response = requests.get(endpoint, params=params)
            if response.status_code == 200:
                data = response.json()
                if 'Items' in data:
                    return data['Items'][:limit]
                else:
                    print(f"No items found for {keywords} in {category}")
                    return []
            else:
                print(f"Error {response.status_code}: {response.text}")
                return []
        except Exception as e:
            print(f"Error searching products: {str(e)}")
            return []
        
    def analyze_product_profitability(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze the profitability of a product based on price, reviews, ratings.
        
        Args:
            product: Product data from Amazon API
            
        Returns:
            Dictionary with profitability analysis
        """
        # Extract product information
        title = product.get('ItemInfo', {}).get('Title', {}).get('DisplayValue', 'Unknown')
        asin = product.get('ASIN', 'Unknown')
        
        # Get price
        price = 0.0
        if 'Offers' in product and 'Listings' in product['Offers'] and len(product['Offers']['Listings']) > 0:
            price_info = product['Offers']['Listings'][0].get('Price', {})
            price = float(price_info.get('Amount', 0))
        
        # Get category
        category = 'Default'
        if 'ItemInfo' in product and 'Classifications' in product['ItemInfo']:
            category = product['ItemInfo']['Classifications'].get('ProductGroup', {}).get('DisplayValue', 'Default')
        
        # Get ratings
        rating = 0.0
        review_count = 0
        if 'CustomerReviews' in product:
            rating = float(product['CustomerReviews'].get('StarRating', {}).get('Value', 0))
            review_count = int(product['CustomerReviews'].get('Count', 0))
        
        # Get sales rank if available
        sales_rank = 999999
        if 'BrowseNodeInfo' in product and 'SalesRank' in product['BrowseNodeInfo']:
            sales_rank = int(product['BrowseNodeInfo']['SalesRank'])
        
        # Calculate commission
        commission_rate = self.commission_rates.get(category, self.commission_rates['Default'])
        estimated_commission = price * (commission_rate / 100)
        
        # Calculate profitability score (0-100)
        # Factors: price, commission rate, rating, review count, sales rank
        price_score = min(50, price / 4) if price > 0 else 0  # Higher price = higher score, max 50
        rating_score = (rating / 5) * 20 if rating > 0 else 0  # Max 20 points for rating
        review_score = min(15, (review_count / 200) * 15) if review_count > 0 else 0  # Max 15 points for reviews
        commission_score = (commission_rate / 10) * 15  # Max 15 points for commission rate
        
        # Sales rank score - lower rank is better
        rank_score = 0
        if sales_rank < 100:
            rank_score = 10
        elif sales_rank < 1000:
            rank_score = 8
        elif sales_rank < 10000:
            rank_score = 5
        elif sales_rank < 50000:
            rank_score = 2
            
        profitability_score = price_score + rating_score + review_score + commission_score + rank_score
        
        # Determine if this product meets our criteria
        meets_criteria = (
            price >= self.min_price and
            price <= self.max_price and
            rating >= self.min_rating and
            review_count >= self.min_reviews
        )
        
        # Create affiliate link
        affiliate_url = f"https://www.amazon.com/dp/{asin}?tag={self.partner_tag}"
        
        return {
            'title': title,
            'asin': asin,
            'price': price,
            'category': category,
            'rating': rating,
            'review_count': review_count,
            'sales_rank': sales_rank,
            'commission_rate': commission_rate,
            'estimated_commission': estimated_commission,
            'profitability_score': profitability_score,
            'meets_criteria': meets_criteria,
            'affiliate_url': affiliate_url
        }
        
    def find_profitable_products(self, 
                                keywords: List[str], 
                                categories: List[str] = ['All'], 
                                limit_per_search: int = 10) -> pd.DataFrame:
        """
        Find profitable products across multiple keywords and categories.
        
        Args:
            keywords: List of keywords to search for
            categories: List of categories to search in
            limit_per_search: Maximum number of results per search
            
        Returns:
            DataFrame with profitable products analysis
        """
        all_results = []
        
        for keyword in keywords:
            for category in categories:
                print(f"Searching for '{keyword}' in category '{category}'...")
                products = self.search_products(keyword, category, limit=limit_per_search)
                
                for product in products:
                    analysis = self.analyze_product_profitability(product)
                    if analysis['meets_criteria']:
                        analysis['keyword'] = keyword
                        analysis['search_category'] = category
                        all_results.append(analysis)
                
                # Sleep to avoid rate limiting
                time.sleep(1)
        
        # Convert to DataFrame and sort by profitability score
        if all_results:
            df = pd.DataFrame(all_results)
            return df.sort_values('profitability_score', ascending=False)
        else:
            return pd.DataFrame()
        
    def export_results(self, df: pd.DataFrame, filename: str = 'profitable_products.csv') -> None:
        """Export results to CSV file."""
        if not df.empty:
            df.to_csv(filename, index=False)
            print(f"Results exported to {filename}")
        else:
            print("No results to export")


# Example usage
if __name__ == "__main__":
    # Amazon Product Advertising API credentials
    ACCESS_KEY = "YOUR_ACCESS_KEY"
    SECRET_KEY = "YOUR_SECRET_KEY"
    PARTNER_TAG = "your-affiliate-tag-20"
    
    # Initialize the agent
    agent = AmazonProductResearchAgent(
        access_key=ACCESS_KEY,
        secret_key=SECRET_KEY,
        partner_tag=PARTNER_TAG,
        region='us',
        min_price=30.0,
        max_price=150.0,
        min_rating=4.2,
        min_reviews=100
    )
    
    # Define search parameters
    keywords = [
        "wireless earbuds",
        "smart home devices",
        "kitchen gadgets",
        "fitness tracker"
    ]
    
    categories = [
        "Electronics",
        "HomeAndKitchen"
    ]
    
    # Find profitable products
    results = agent.find_profitable_products(
        keywords=keywords,
        categories=categories,
        limit_per_search=5
    )
    
    # Print top 5 results
    if not results.empty:
        print("\nTop 5 Most Profitable Products:")
        top_results = results.head(5)
        for i, row in top_results.iterrows():
            print(f"{i+1}. {row['title']}")
            print(f"   Price: ${row['price']:.2f} | Rating: {row['rating']}/5 ({row['review_count']} reviews)")
            print(f"   Commission Rate: {row['commission_rate']}% | Est. Commission: ${row['estimated_commission']:.2f}")
            print(f"   Profitability Score: {row['profitability_score']:.1f}/100")
            print(f"   Affiliate Link: {row['affiliate_url']}")
            print()
    
    # Export results
    agent.export_results(results)
`;

export const amazonApiDocumentation = `
Setting up Amazon Product Advertising API:

1. Register for an Amazon Associates account at https://affiliate-program.amazon.com/
2. Once approved, sign up for the Product Advertising API at https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html
3. Generate an access key and secret key from your Amazon Associates account
4. Install required Python packages: pip install requests pandas boto3
5. Replace YOUR_ACCESS_KEY, YOUR_SECRET_KEY, and your-affiliate-tag-20 in the script
6. Run the script to find profitable products for your affiliate marketing business

Note: Amazon's API has request limitations. Please review Amazon's terms of service and API documentation for the most current requirements and limitations.
`;
