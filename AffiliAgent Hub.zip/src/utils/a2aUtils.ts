import { A2AMessage, A2ATask, A2ACollaborationResult } from '../types/a2aTypes';

/**
 * Formats a message according to A2A protocol
 */
export function formatA2AMessage(
  sender: string,
  messageType: 'request' | 'response' | 'broadcast',
  content: string,
  taskId?: string,
  receiver?: string
): A2AMessage {
  return {
    agentName: sender,
    messageType,
    content,
    timestamp: new Date().toISOString(),
    taskId,
    priority: 3,
    references: []
  };
}

/**
 * Simulates an A2A collaboration between agents
 */
export async function simulateA2ACollaboration(
  initiatingAgent: string,
  task: string,
  involvedAgents: string[]
): Promise<A2ACollaborationResult> {
  const taskId = `task-${Date.now()}`;
  const startTime = new Date().toISOString();
  
  // Simulated collaboration messages
  const messages: A2AMessage[] = [];
  
  // Initial request from initiating agent
  messages.push(formatA2AMessage(
    initiatingAgent,
    'broadcast',
    `Task: ${task}. I need assistance with this.`,
    taskId
  ));
  
  // Wait 1 second to simulate processing time
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Generate responses from other agents
  for (const agent of involvedAgents) {
    if (agent !== initiatingAgent) {
      messages.push(formatA2AMessage(
        agent,
        'response',
        `I can help with this task. My specialization in ${agent.toLowerCase()} will be valuable.`,
        taskId,
        initiatingAgent
      ));
      
      // Simulate different response times
      await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
    }
  }
  
  // More realistic collaboration messages for wireless earbuds
  messages.push(formatA2AMessage(
    initiatingAgent,
    'request',
    `Great, let's collaborate on this affiliate marketing campaign for wireless earbuds. SEO Optimization Agent, please research keywords for wireless earbuds with high search volume and buyer intent.`,
    taskId
  ));
  
  await new Promise(resolve => setTimeout(resolve, 1200));
  
  const seoAgent = involvedAgents.find(a => a.includes('SEO')) || involvedAgents[0];
  messages.push(formatA2AMessage(
    seoAgent,
    'response',
    `Beginning keyword research for wireless earbuds. Initial findings indicate high search volume for: "best wireless earbuds 2025", "noise cancelling wireless earbuds", "wireless earbuds for running", and "wireless earbuds with long battery life".`,
    taskId,
    initiatingAgent
  ));
  
  await new Promise(resolve => setTimeout(resolve, 1400));
  
  const contentAgent = involvedAgents.find(a => a.includes('Content')) || involvedAgents[0];
  messages.push(formatA2AMessage(
    contentAgent,
    'request',
    `Using the keywords provided by ${seoAgent}, I'll create outlines for 3 different content pieces: a comparison review, a "best of" roundup, and a buyer's guide. @Customer Behavior Analyst: Can you provide insights on the typical customer journey for wireless earbuds buyers?`,
    taskId,
    initiatingAgent
  ));
  
  await new Promise(resolve => setTimeout(resolve, 1100));
  
  const behaviorAgent = involvedAgents.find(a => a.includes('Customer')) || involvedAgents[1];
  messages.push(formatA2AMessage(
    behaviorAgent,
    'response',
    `Analysis shows wireless earbuds buyers typically spend 2-3 weeks researching before purchase. They prioritize: 1) Sound quality, 2) Battery life, 3) Comfort, 4) Noise cancellation, 5) Price. 62% read at least 3 reviews before deciding. Most conversions happen on product comparison pages rather than single product reviews.`,
    taskId,
    contentAgent
  ));
  
  await new Promise(resolve => setTimeout(resolve, 1300));
  
  messages.push(formatA2AMessage(
    initiatingAgent,
    'request',
    `Excellent collaboration. Let's integrate our findings: \n1. Focus on the identified keywords \n2. Create comparison content highlighting the top 5 buyer priorities \n3. Structure content for 2-3 week research journey \n4. Optimize for affiliate conversions on comparison pages \n\nIs everyone aligned on this strategy?`,
    taskId
  ));
  
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Confirmations from all agents
  for (const agent of involvedAgents) {
    if (agent !== initiatingAgent) {
      messages.push(formatA2AMessage(
        agent,
        'response',
        `Confirmed. Ready to implement the strategy from my ${agent.replace(' Agent', '').toLowerCase()} specialization.`,
        taskId,
        initiatingAgent
      ));
      
      // Simulate different response times
      await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 500));
    }
  }
  
  // Conclude collaboration
  const endTime = new Date().toISOString();
  
  return {
    taskId,
    startTime,
    endTime,
    agentsInvolved: [initiatingAgent, ...involvedAgents],
    messages,
    outcome: `Collaboration complete. Created a comprehensive affiliate marketing strategy for wireless earbuds targeting high-value keywords, optimized for the typical 2-3 week buyer journey, with content structured to maximize conversions on product comparison pages.`,
    artifacts: [
      {
        name: "Keyword Research Report",
        type: "document",
        creator: seoAgent,
        summary: "Analysis of top-performing wireless earbuds keywords with search volume and competition metrics"
      },
      {
        name: "Content Strategy Document",
        type: "document",
        creator: contentAgent,
        summary: "Outlines for 3 content pieces optimized for conversion"
      },
      {
        name: "Buyer Behavior Analysis",
        type: "data",
        creator: behaviorAgent,
        summary: "Detailed customer journey map for wireless earbuds purchasers"
      }
    ]
  };
}

/**
 * Creates a new A2A Task
 */
export function createA2ATask(
  title: string,
  description: string,
  assignedAgents: string[]
): A2ATask {
  const now = new Date().toISOString();
  
  return {
    id: `task-${Date.now()}`,
    title,
    description,
    status: 'pending',
    assignedAgents,
    createdAt: now,
    updatedAt: now,
    messages: []
  };
}

/**
 * Formats the A2A message for display
 */
export function formatA2AMessageForDisplay(message: A2AMessage): string {
  return `[${message.agentName}] (${message.messageType.toUpperCase()}): ${message.content}`;
}

/**
 * Compare A2A with Actor Model approach
 * This function returns a comparison between Google's A2A framework and the Actor Model pattern from actor-core
 */
export function compareA2AWithActorModel(): { a2a: string[], actorModel: string[] } {
  return {
    a2a: [
      "Focused on standardized communication protocol",
      "Designed specifically for LLM agent collaboration",
      "Emphasis on message format and semantics",
      "Built-in task coordination",
      "Less opinionated about internal agent implementation"
    ],
    actorModel: [
      "Mathematical model for concurrent computation",
      "Strong focus on encapsulation and isolation",
      "Built-in supervision hierarchies",
      "Location transparency (local vs distributed)",
      "Emphasis on fault tolerance and resilience"
    ]
  };
}
