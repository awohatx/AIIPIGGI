// A2A Types based on Google's Agent-to-Agent communication framework

export interface A2AMessage {
  agentName: string;
  messageType: 'request' | 'response' | 'broadcast';
  content: string;
  timestamp: string;
  taskId?: string;
  priority?: number;
  references?: string[];
}

export interface AgentCapability {
  agentName: string;
  capabilities: string[];
}

export interface A2ATask {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  assignedAgents: string[];
  createdAt: string;
  updatedAt: string;
  messages: A2AMessage[];
}

export interface A2ACollaborationResult {
  taskId: string;
  startTime: string;
  endTime: string;
  agentsInvolved: string[];
  messages: A2AMessage[];
  outcome: string;
  artifacts: any[];
}

// A2A Message Schema (reference implementation)
export const a2aMessageSchema = {
  type: 'object',
  properties: {
    sender: { type: 'string' },
    receiver: { type: 'string' },
    message_type: { 
      type: 'string',
      enum: ['request', 'response', 'broadcast'] 
    },
    content: { type: 'string' },
    context: {
      type: 'object',
      properties: {
        task_id: { type: 'string' },
        priority: { type: 'number', minimum: 1, maximum: 5 },
        references: { type: 'array', items: { type: 'string' } }
      }
    },
    timestamp: { type: 'string', format: 'date-time' }
  },
  required: ['sender', 'message_type', 'content', 'timestamp']
};
