import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend: string;
}

export default function StatCard({ title, value, icon, trend }: StatCardProps) {
  const isTrendPositive = trend.startsWith('+');
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 transition-all duration-300 hover:shadow-md hover:translate-y-[-2px]">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-gray-600 text-sm font-medium">{title}</h3>
          <p className="text-2xl font-bold text-gray-800 mt-1">{value}</p>
        </div>
        <div className="p-2 rounded-full bg-gradient-to-br from-gray-50 to-gray-100">
          {icon}
        </div>
      </div>
      <div className={`mt-4 text-sm flex items-center ${isTrendPositive ? 'text-emerald-600' : 'text-red-600'}`}>
        <span className="font-medium">{trend}</span>
        <span className="ml-1 text-gray-500 text-xs">from last period</span>
      </div>
    </div>
  );
}
