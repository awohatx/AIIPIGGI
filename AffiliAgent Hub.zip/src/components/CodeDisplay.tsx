import { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface CodeDisplayProps {
  code: string;
  language?: string;
  title?: string;
  description?: string;
}

export default function CodeDisplay({ 
  code, 
  language = 'python', 
  title = 'Code Snippet', 
  description 
}: CodeDisplayProps) {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="bg-gray-100 px-4 py-2 flex justify-between items-center">
        <div>
          <h3 className="font-medium text-gray-800">{title}</h3>
          {language && (
            <span className="text-xs font-mono text-gray-500">{language}</span>
          )}
        </div>
        <button
          onClick={copyToClipboard}
          className="flex items-center space-x-1 text-sm bg-white hover:bg-gray-50 text-gray-700 px-3 py-1 rounded border transition-colors duration-200"
        >
          {copied ? (
            <>
              <Check size={16} className="text-green-600" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy size={16} />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      
      {description && (
        <div className="px-4 py-2 border-b text-sm text-gray-600">
          {description}
        </div>
      )}
      
      <div className="overflow-x-auto max-h-96">
        <pre className="p-4 text-sm font-mono whitespace-pre-wrap bg-gray-50 text-gray-800">
          {code}
        </pre>
      </div>
    </div>
  );
}
