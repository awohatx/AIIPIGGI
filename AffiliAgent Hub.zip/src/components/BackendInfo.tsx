import { useState } from 'react';
import { ChevronDown, ChevronUp, Cloud, Code, Database, ExternalLink, Lock, Server } from 'lucide-react';
import CodeDisplay from './CodeDisplay';

export default function BackendInfo() {
  const [expandedSection, setExpandedSection] = useState<string | null>('api');

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };

  const expressServerCode = `
// server.js - Express API Server

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// User model
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  amazonAssociateId: { type: String },
  amazonApiKey: { type: String },
  amazonApiSecret: { type: String },
  createdAt: { type: Date, default: Date.now }
});

// Product model
const productSchema = new mongoose.Schema({
  asin: { type: String, required: true },
  title: { type: String, required: true },
  description: { type: String },
  price: { type: Number },
  imageUrl: { type: String },
  category: { type: String },
  rating: { type: Number },
  reviewCount: { type: Number },
  affiliateUrl: { type: String },
  commission: { type: Number },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

const User = mongoose.model('User', userSchema);
const Product = mongoose.model('Product', productSchema);

// Auth middleware
const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) return res.status(401).json({ message: 'No token provided' });
  
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
};

// Routes
app.post('/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create new user
    const newUser = new User({
      email,
      password: hashedPassword
    });
    
    const savedUser = await newUser.save();
    
    // Generate token
    const token = jwt.sign({ id: savedUser._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
    
    res.status(201).json({ token, userId: savedUser._id });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Generate token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
    
    res.json({ token, userId: user._id });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Protected product routes
app.get('/api/products', authenticateToken, async (req, res) => {
  try {
    const products = await Product.find({ userId: req.user.id });
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

app.post('/api/products', authenticateToken, async (req, res) => {
  try {
    const newProduct = new Product({
      ...req.body,
      userId: req.user.id
    });
    
    const savedProduct = await newProduct.save();
    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Amazon API integration endpoint
app.get('/api/amazon/search', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    if (!user.amazonApiKey || !user.amazonApiSecret || !user.amazonAssociateId) {
      return res.status(400).json({ message: 'Amazon API credentials not configured' });
    }
    
    // Implement Amazon Product API search here
    // This would use the user's Amazon API credentials to search for products
    
    res.json({ message: 'Amazon API integration to be implemented' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// A2A collaboration endpoint
app.post('/api/a2a/collaborate', authenticateToken, async (req, res) => {
  try {
    const { task, agents } = req.body;
    
    // Implement A2A collaboration logic here
    // This would handle communication between different agent types
    
    res.json({ message: 'A2A collaboration to be implemented' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});
`;

  const awsInfraCode = `
# AWS Infrastructure using CloudFormation

AWSTemplateFormatVersion: '2010-09-09'
Description: 'AffiliAgent Hub Infrastructure'
Resources:
  # VPC and Networking
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: 10.0.0.0/16
      EnableDnsSupport: true
      EnableDnsHostnames: true
      Tags:
        - Key: Name
          Value: AffiliAgentVPC

  # Database - MongoDB Atlas Integration via API Gateway
  MongoDBAtlasIntegration:
    Type: AWS::ApiGateway::RestApi
    Properties:
      Name: MongoDBAtlasIntegration
      Description: API for MongoDB Atlas Integration

  # EC2 Instance for Backend API
  BackendInstance:
    Type: AWS::EC2::Instance
    Properties:
      InstanceType: t3.small
      ImageId: ami-0c55b159cbfafe1f0 # Amazon Linux 2
      SecurityGroupIds:
        - !Ref BackendSecurityGroup
      UserData:
        Fn::Base64: !Sub |
          #!/bin/bash
          yum update -y
          curl -sL https://rpm.nodesource.com/setup_16.x | bash -
          yum install -y nodejs
          cd /home/ec2-user
          git clone https://github.com/yourrepo/affiliagent-backend.git
          cd affiliagent-backend
          npm install
          npm run start

  # Security Group for Backend
  BackendSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: Security group for backend API
      VpcId: !Ref VPC
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 22
          ToPort: 22
          CidrIp: 0.0.0.0/0
        - IpProtocol: tcp
          FromPort: 5000
          ToPort: 5000
          CidrIp: 0.0.0.0/0

  # S3 Bucket for Frontend
  FrontendBucket:
    Type: AWS::S3::Bucket
    Properties:
      BucketName: affiliagent-hub-frontend
      WebsiteConfiguration:
        IndexDocument: index.html
        ErrorDocument: index.html
      PublicAccessBlockConfiguration:
        BlockPublicAcls: false
        BlockPublicPolicy: false
        IgnorePublicAcls: false
        RestrictPublicBuckets: false

  # CloudFront for Frontend Distribution
  FrontendDistribution:
    Type: AWS::CloudFront::Distribution
    Properties:
      DistributionConfig:
        Origins:
          - DomainName: !GetAtt FrontendBucket.DomainName
            Id: S3Origin
            S3OriginConfig:
              OriginAccessIdentity: ''
        Enabled: true
        DefaultRootObject: index.html
        DefaultCacheBehavior:
          TargetOriginId: S3Origin
          ViewerProtocolPolicy: redirect-to-https
          AllowedMethods:
            - GET
            - HEAD
            - OPTIONS
          CachedMethods:
            - GET
            - HEAD
            - OPTIONS
          ForwardedValues:
            QueryString: false
            Cookies:
              Forward: none

  # Lambda for Amazon API Integration
  AmazonApiFunction:
    Type: AWS::Lambda::Function
    Properties:
      Handler: index.handler
      Role: !GetAtt LambdaExecutionRole.Arn
      Runtime: nodejs16.x
      Code:
        ZipFile: |
          exports.handler = async (event) => {
            // Integrate with Amazon Product Advertising API
            // This would handle the API requests and responses
            const response = {
              statusCode: 200,
              body: JSON.stringify('Amazon API integration'),
            };
            return response;
          };

  # IAM Role for Lambda
  LambdaExecutionRole:
    Type: AWS::IAM::Role
    Properties:
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: lambda.amazonaws.com
            Action: 'sts:AssumeRole'
      ManagedPolicyArns:
        - 'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'

Outputs:
  FrontendURL:
    Description: URL of the frontend website
    Value: !GetAtt FrontendBucket.WebsiteURL
  
  BackendEndpoint:
    Description: Endpoint for the backend API
    Value: !Sub 'http://${BackendInstance.PublicDnsName}:5000'
`;

  const dotenvExample = `
# .env file for backend server

# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Connection
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/affiliagent?retryWrites=true&w=majority

# JWT Authentication
JWT_SECRET=your_very_secure_jwt_secret_key

# Amazon Product Advertising API
AMAZON_ACCESS_KEY=your_amazon_access_key
AMAZON_SECRET_KEY=your_amazon_secret_key
AMAZON_PARTNER_TAG=your-affiliate-tag-20
AMAZON_REGION=us

# AWS Configuration
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
`;

  const dockerComposeCode = `
version: '3'

services:
  # Node.js API backend
  api:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "5000:5000"
    depends_on:
      - mongo
    environment:
      - PORT=5000
      - MONGODB_URI=mongodb://mongo:27017/affiliagent
      - JWT_SECRET=your_jwt_secret
      - NODE_ENV=development
    volumes:
      - ./backend:/usr/src/app
      - /usr/src/app/node_modules
    restart: unless-stopped

  # MongoDB database
  mongo:
    image: mongo:latest
    ports:
      - "27017:27017"
    volumes:
      - mongo-data:/data/db
    restart: unless-stopped

  # React frontend
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "3000:80"
    volumes:
      - ./frontend:/usr/src/app
      - /usr/src/app/node_modules
    restart: unless-stopped
    depends_on:
      - api

volumes:
  mongo-data:
`;

  const awsCicdCode = `
# GitHub Actions workflow for CI/CD deployment to AWS
# .github/workflows/deploy.yml

name: Deploy to AWS

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: 16
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build
      run: npm run build
      
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v1
      with:
        aws-access-key-id: \${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1
        
    - name: Deploy frontend to S3
      run: |
        aws s3 sync ./dist s3://affiliagent-hub-frontend/ --delete
        
    - name: Invalidate CloudFront cache
      run: |
        aws cloudfront create-invalidation --distribution-id \${{ secrets.CLOUDFRONT_DISTRIBUTION_ID }} --paths "/*"
        
    - name: Deploy backend to EC2
      uses: appleboy/ssh-action@master
      with:
        host: \${{ secrets.EC2_HOST }}
        username: \${{ secrets.EC2_USERNAME }}
        key: \${{ secrets.EC2_SSH_KEY }}
        script: |
          cd /home/ec2-user/affiliagent-backend
          git pull
          npm ci
          pm2 restart all
`;

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          Backend & Cloud Setup for AffiliAgent Hub
        </h2>
        <p className="text-gray-600 mb-6">
          To transform your frontend prototype into a production-ready application, you'll need the following backend and cloud infrastructure components.
        </p>

        <div className="space-y-4">
          {/* API Server Section */}
          <div className="border rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 cursor-pointer ${expandedSection === 'api' ? 'bg-blue-50' : 'bg-gray-50'}`}
              onClick={() => toggleSection('api')}
            >
              <div className="flex items-center">
                <Server className="text-blue-600 mr-3" size={20} />
                <h3 className="font-semibold">API Server (Node.js/Express)</h3>
              </div>
              {expandedSection === 'api' ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
            
            {expandedSection === 'api' && (
              <div className="p-4">
                <p className="text-gray-700 mb-4">
                  You'll need a RESTful API server to handle authentication, product management, and integration with Amazon's Product Advertising API. 
                  Express.js is recommended for its simplicity and flexibility.
                </p>
                
                <div className="mb-4">
                  <h4 className="font-medium text-gray-800 mb-2">Key Features:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>User authentication and management</li>
                    <li>Product CRUD operations</li>
                    <li>Amazon API proxy to protect your API keys</li>
                    <li>Agent-to-Agent (A2A) communication endpoints</li>
                    <li>Analytics data collection</li>
                  </ul>
                </div>
                
                <CodeDisplay 
                  code={expressServerCode}
                  language="javascript"
                  title="server.js"
                  description="Express.js API server implementation with MongoDB, JWT authentication, and Amazon API integration"
                />
                
                <div className="mt-4 text-gray-700">
                  <h4 className="font-medium text-gray-800 mb-2">Required Packages:</h4>
                  <code className="bg-gray-100 px-2 py-1 rounded text-sm block">
                    npm install express mongoose cors jsonwebtoken bcrypt dotenv axios
                  </code>
                </div>
              </div>
            )}
          </div>
          
          {/* Database Section */}
          <div className="border rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 cursor-pointer ${expandedSection === 'database' ? 'bg-blue-50' : 'bg-gray-50'}`}
              onClick={() => toggleSection('database')}
            >
              <div className="flex items-center">
                <Database className="text-green-600 mr-3" size={20} />
                <h3 className="font-semibold">Database (MongoDB)</h3>
              </div>
              {expandedSection === 'database' ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
            
            {expandedSection === 'database' && (
              <div className="p-4">
                <p className="text-gray-700 mb-4">
                  MongoDB is recommended for your application due to its flexibility with document-based data and ease of scaling. 
                  MongoDB Atlas provides a managed cloud database service with a free tier to get started.
                </p>
                
                <div className="mb-4">
                  <h4 className="font-medium text-gray-800 mb-2">Data Models:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li><span className="font-mono text-sm">User</span> - Store user information and Amazon API credentials</li>
                    <li><span className="font-mono text-sm">Product</span> - Track products from Amazon for affiliate links</li>
                    <li><span className="font-mono text-sm">AgentTask</span> - Store A2A collaboration tasks and results</li>
                    <li><span className="font-mono text-sm">Analytics</span> - Track clicks, conversions, and revenue</li>
                  </ul>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-800 mb-2">Setup Instructions:</h4>
                  <ol className="list-decimal pl-5 space-y-1 text-gray-600">
                    <li>Create a free MongoDB Atlas account at <a href="https://www.mongodb.com/cloud/atlas" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">mongodb.com/cloud/atlas</a></li>
                    <li>Set up a new cluster (the free tier is sufficient for development)</li>
                    <li>Create a database user with read/write permissions</li>
                    <li>Allow access from your IP address or set to allow access from anywhere for development</li>
                    <li>Copy your connection string and add it to your .env file</li>
                  </ol>
                </div>
                
                <div className="mt-4">
                  <h4 className="font-medium text-gray-800 mb-2">Environment Variables:</h4>
                  <CodeDisplay 
                    code={dotenvExample}
                    language="bash"
                    title=".env"
                    description="Environment variables for backend configuration"
                  />
                </div>
              </div>
            )}
          </div>
          
          {/* Authentication Section */}
          <div className="border rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 cursor-pointer ${expandedSection === 'auth' ? 'bg-blue-50' : 'bg-gray-50'}`}
              onClick={() => toggleSection('auth')}
            >
              <div className="flex items-center">
                <Lock className="text-yellow-600 mr-3" size={20} />
                <h3 className="font-semibold">Authentication System</h3>
              </div>
              {expandedSection === 'auth' ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
            
            {expandedSection === 'auth' && (
              <div className="p-4">
                <p className="text-gray-700 mb-4">
                  Implement JWT (JSON Web Token) authentication to secure your API and manage user sessions.
                  This allows you to protect routes and user data while providing a good user experience.
                </p>
                
                <div className="mb-4">
                  <h4 className="font-medium text-gray-800 mb-2">Authentication Flow:</h4>
                  <ol className="list-decimal pl-5 space-y-1 text-gray-600">
                    <li>User registers or logs in with credentials</li>
                    <li>Server validates credentials and generates a JWT token</li>
                    <li>Token is sent to client and stored in localStorage or HTTP-only cookie</li>
                    <li>Client includes token in Authorization header for protected requests</li>
                    <li>Server verifies token and grants access to protected resources</li>
                  </ol>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <h4 className="font-medium text-gray-800 mb-2">Security Considerations:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>Use HTTPS in production to prevent token interception</li>
                    <li>Implement token expiration and refresh token rotation</li>
                    <li>Store sensitive user information (Amazon API keys) encrypted in the database</li>
                    <li>Implement rate limiting to prevent brute force attacks</li>
                    <li>Consider using HTTP-only cookies instead of localStorage for added security</li>
                  </ul>
                </div>
                
                <div className="text-gray-700">
                  <p className="mb-2">
                    The authentication system is already included in the Express server code above. Key packages:
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li><span className="font-mono text-sm">jsonwebtoken</span> - For creating and verifying JWT tokens</li>
                    <li><span className="font-mono text-sm">bcrypt</span> - For securely hashing and comparing passwords</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
          
          {/* AWS Cloud Infrastructure Section */}
          <div className="border rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 cursor-pointer ${expandedSection === 'cloud' ? 'bg-blue-50' : 'bg-gray-50'}`}
              onClick={() => toggleSection('cloud')}
            >
              <div className="flex items-center">
                <Cloud className="text-purple-600 mr-3" size={20} />
                <h3 className="font-semibold">AWS Cloud Infrastructure</h3>
              </div>
              {expandedSection === 'cloud' ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
            
            {expandedSection === 'cloud' && (
              <div className="p-4">
                <p className="text-gray-700 mb-4">
                  AWS (Amazon Web Services) is ideal for your platform since you're building an Amazon affiliate application. 
                  This provides synergy with Amazon's services and can simplify integration.
                </p>
                
                <div className="mb-4">
                  <h4 className="font-medium text-gray-800 mb-2">Key AWS Services:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li><span className="font-medium">S3</span> - For hosting your React frontend</li>
                    <li><span className="font-medium">EC2</span> - For running your Node.js backend server</li>
                    <li><span className="font-medium">CloudFront</span> - CDN for fast global content delivery</li>
                    <li><span className="font-medium">Lambda</span> - For serverless functions (Amazon API requests)</li>
                    <li><span className="font-medium">API Gateway</span> - For creating RESTful APIs and connecting to Lambda</li>
                    <li><span className="font-medium">Route 53</span> - For domain management (when you're ready)</li>
                  </ul>
                </div>
                
                <CodeDisplay 
                  code={awsInfraCode}
                  language="yaml"
                  title="cloudformation.yml"
                  description="AWS CloudFormation template for infrastructure as code"
                />
                
                <div className="mt-4">
                  <h4 className="font-medium text-gray-800 mb-2">Deployment Pipeline:</h4>
                  <CodeDisplay 
                    code={awsCicdCode}
                    language="yaml"
                    title=".github/workflows/deploy.yml"
                    description="GitHub Actions workflow for CI/CD deployment to AWS"
                  />
                </div>
              </div>
            )}
          </div>
          
          {/* Docker Development Environment */}
          <div className="border rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 cursor-pointer ${expandedSection === 'docker' ? 'bg-blue-50' : 'bg-gray-50'}`}
              onClick={() => toggleSection('docker')}
            >
              <div className="flex items-center">
                <Code className="text-indigo-600 mr-3" size={20} />
                <h3 className="font-semibold">Docker Development Environment</h3>
              </div>
              {expandedSection === 'docker' ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
            
            {expandedSection === 'docker' && (
              <div className="p-4">
                <p className="text-gray-700 mb-4">
                  Dockerizing your development environment ensures consistency across team members and simplifies deployment.
                  This Docker Compose setup includes your frontend, backend API, and MongoDB database.
                </p>
                
                <CodeDisplay 
                  code={dockerComposeCode}
                  language="yaml"
                  title="docker-compose.yml"
                  description="Docker Compose configuration for local development"
                />
                
                <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-800 mb-2">Getting Started with Docker:</h4>
                  <ol className="list-decimal pl-5 space-y-1 text-gray-600">
                    <li>Install Docker and Docker Compose on your development machine</li>
                    <li>Create a <span className="font-mono text-sm">backend</span> folder with your Express server code</li>
                    <li>Create a <span className="font-mono text-sm">frontend</span> folder with your React application</li>
                    <li>Add Dockerfiles to both folders</li>
                    <li>Run <span className="font-mono text-sm">docker-compose up</span> to start the development environment</li>
                  </ol>
                </div>
                
                <div className="mt-4">
                  <p className="text-gray-700">
                    This setup allows you to develop locally with hot reloading while maintaining an environment 
                    that closely resembles your production deployment.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8 border-t pt-6">
          <h3 className="font-semibold mb-3">Next Steps</h3>
          <p className="text-gray-700 mb-4">
            To proceed with implementing the backend and cloud infrastructure:
          </p>
          <ol className="list-decimal pl-5 space-y-2 text-gray-600">
            <li>Create a new repository for your backend server</li>
            <li>Set up the Express server with authentication and basic routes</li>
            <li>Create a MongoDB Atlas account and configure the database connection</li>
            <li>Register for Amazon Product Advertising API access</li>
            <li>Create an AWS account and set up the basic infrastructure</li>
            <li>Modify the frontend to connect to your new backend</li>
          </ol>
          
          <div className="mt-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
            <p className="text-blue-800">
              <span className="font-semibold">Recommendation:</span> Start with a simple backend implementation locally, then 
              gradually integrate with Amazon's API and deploy to AWS as your application matures.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
