import { useState } from 'react';
import { Check, Copy, Save } from 'lucide-react';

interface SEOAgentConfigProps {
  onSave: (config: SEOAgentConfig) => void;
  defaultConfig?: SEOAgentConfig;
}

export interface SEOAgentConfig {
  productCategories: string[];
  detailLevel: 'concise' | 'detailed';
  preferredTools: string[];
  focusAreas: string[];
}

export default function SEOAgentConfig({ onSave, defaultConfig }: SEOAgentConfigProps) {
  const [config, setConfig] = useState<SEOAgentConfig>(defaultConfig || {
    productCategories: [],
    detailLevel: 'concise',
    preferredTools: [],
    focusAreas: []
  });
  
  const [copied, setCopied] = useState(false);
  
  const productCategoryOptions = [
    'Electronics', 'Home & Kitchen', 'Books', 'Fashion', 'Beauty', 
    'Sports & Outdoors', 'Toys & Games', 'Health & Personal Care'
  ];
  
  const toolOptions = [
    'Ahrefs', 'SEMrush', 'Google Keyword Planner', 'Moz', 'Ubersuggest',
    'AnswerThePublic', 'KeywordTool.io', 'Screaming Frog SEO Spider'
  ];
  
  const focusAreaOptions = [
    'On-page SEO', 'Keyword Research', 'Content Optimization', 
    'Competitive Analysis', 'Internal Linking', 'Schema Markup',
    'Mobile Optimization', 'Page Speed Optimization'
  ];
  
  const handleCategoryChange = (category: string) => {
    if (config.productCategories.includes(category)) {
      setConfig({
        ...config,
        productCategories: config.productCategories.filter(c => c !== category)
      });
    } else {
      setConfig({
        ...config,
        productCategories: [...config.productCategories, category]
      });
    }
  };
  
  const handleToolChange = (tool: string) => {
    if (config.preferredTools.includes(tool)) {
      setConfig({
        ...config,
        preferredTools: config.preferredTools.filter(t => t !== tool)
      });
    } else {
      setConfig({
        ...config,
        preferredTools: [...config.preferredTools, tool]
      });
    }
  };
  
  const handleFocusAreaChange = (area: string) => {
    if (config.focusAreas.includes(area)) {
      setConfig({
        ...config,
        focusAreas: config.focusAreas.filter(a => a !== area)
      });
    } else {
      setConfig({
        ...config,
        focusAreas: [...config.focusAreas, area]
      });
    }
  };
  
  const generatePrompt = () => {
    let prompt = `You are an SEO Optimization Agent specializing in Amazon affiliate marketing. Your goal is to maximize organic traffic and conversion rates through strategic keyword optimization.`;
    
    if (config.productCategories.length > 0) {
      prompt += `\n\nFocus on the following product categories: ${config.productCategories.join(', ')}.`;
    } else {
      prompt += `\n\nProvide general SEO recommendations across various Amazon product categories.`;
    }
    
    prompt += `\n\nProvide ${config.detailLevel === 'concise' ? 'concise and actionable' : 'detailed and comprehensive'} analysis and recommendations.`;
    
    if (config.preferredTools.length > 0) {
      prompt += `\n\nUtilize the following tools for research and analysis: ${config.preferredTools.join(', ')}.`;
    }
    
    if (config.focusAreas.length > 0) {
      prompt += `\n\nSpecifically focus on: ${config.focusAreas.join(', ')}.`;
    }
    
    prompt += `\n\nTASK:
1. Research high-value keywords related to specific products with:
   - Monthly search volume data
   - Competition analysis
   - Buyer intent assessment
2. Analyze existing content and provide optimization recommendations:
   - Title improvements
   - Meta description enhancements
   - Heading structure optimization
   - Image alt text suggestions
   - Internal linking opportunities
3. Identify content gaps that should be addressed
4. Suggest topic clusters around main product categories
5. Provide a comprehensive SEO strategy with:
   - Primary and secondary keywords for each page
   - Content calendar recommendations
   - Performance tracking metrics

Focus on long-tail keywords with buyer intent and include recommendations for schema markup where applicable. Prioritize user experience while optimizing for search engines.`;
    
    return prompt;
  };
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatePrompt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const handleSave = () => {
    onSave(config);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
      <div>
        <h3 className="font-semibold mb-3">1. Select Product Categories</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {productCategoryOptions.map(category => (
            <div key={category} className="flex items-center">
              <input
                type="checkbox"
                id={`category-${category}`}
                className="mr-2 h-4 w-4 text-blue-600 rounded"
                checked={config.productCategories.includes(category)}
                onChange={() => handleCategoryChange(category)}
              />
              <label htmlFor={`category-${category}`} className="text-sm">{category}</label>
            </div>
          ))}
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold mb-3">2. Analysis Detail Level</h3>
        <div className="flex space-x-4">
          <div className="flex items-center">
            <input
              type="radio"
              id="concise"
              className="mr-2 h-4 w-4 text-blue-600"
              checked={config.detailLevel === 'concise'}
              onChange={() => setConfig({...config, detailLevel: 'concise'})}
            />
            <label htmlFor="concise" className="text-sm">Concise Recommendations</label>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              id="detailed"
              className="mr-2 h-4 w-4 text-blue-600"
              checked={config.detailLevel === 'detailed'}
              onChange={() => setConfig({...config, detailLevel: 'detailed'})}
            />
            <label htmlFor="detailed" className="text-sm">Detailed Analysis</label>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold mb-3">3. Preferred Research Tools</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {toolOptions.map(tool => (
            <div key={tool} className="flex items-center">
              <input
                type="checkbox"
                id={`tool-${tool}`}
                className="mr-2 h-4 w-4 text-blue-600 rounded"
                checked={config.preferredTools.includes(tool)}
                onChange={() => handleToolChange(tool)}
              />
              <label htmlFor={`tool-${tool}`} className="text-sm">{tool}</label>
            </div>
          ))}
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold mb-3">4. SEO Focus Areas</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {focusAreaOptions.map(area => (
            <div key={area} className="flex items-center">
              <input
                type="checkbox"
                id={`area-${area}`}
                className="mr-2 h-4 w-4 text-blue-600 rounded"
                checked={config.focusAreas.includes(area)}
                onChange={() => handleFocusAreaChange(area)}
              />
              <label htmlFor={`area-${area}`} className="text-sm">{area}</label>
            </div>
          ))}
        </div>
      </div>
      
      <div className="border-t pt-4">
        <h3 className="font-semibold mb-3">Generated Prompt</h3>
        <div className="bg-gray-50 p-3 rounded-md text-sm font-mono h-48 overflow-y-auto">
          {generatePrompt().split('\n').map((line, i) => (
            <div key={i} className={line.startsWith('TASK:') ? 'font-semibold mt-2' : ''}>
              {line || <br />}
            </div>
          ))}
        </div>
        
        <div className="flex justify-end space-x-2 mt-4">
          <button
            onClick={copyToClipboard}
            className="flex items-center border border-blue-600 text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
          >
            {copied ? <Check size={16} className="mr-2" /> : <Copy size={16} className="mr-2" />}
            {copied ? 'Copied!' : 'Copy Prompt'}
          </button>
          <button
            onClick={handleSave}
            className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
          >
            <Save size={16} className="mr-2" />
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
}
