import { useState, useEffect } from 'react';
import { ArrowRight, ChartBar, BrainCircuit, Check, Copy, MessageSquare, RefreshCw, Zap } from 'lucide-react';
import { A2AMessage, AgentCapability } from '../types/a2aTypes';

interface A2ACollaborationProps {
  onRunCollaboration: () => void;
  isLoading?: boolean;
}

export default function A2ACollaboration({ onRunCollaboration, isLoading = false }: A2ACollaborationProps) {
  const [showExample, setShowExample] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [activeConversation, setActiveConversation] = useState<A2AMessage[]>([]);
  const [visualizationStep, setVisualizationStep] = useState(0);

  useEffect(() => {
    if (showExample) {
      // Animate the conversation flowing in
      const timer = setTimeout(() => {
        setActiveConversation([exampleMessages[0]]);
        
        const timer2 = setTimeout(() => {
          setActiveConversation([exampleMessages[0], exampleMessages[1]]);
          
          const timer3 = setTimeout(() => {
            setActiveConversation([...exampleMessages]);
          }, 1500);
          
          return () => clearTimeout(timer3);
        }, 1500);
        
        return () => clearTimeout(timer2);
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [showExample]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };
  
  // Function to simulate a live conversation between agents
  const startVisualization = () => {
    setVisualizationStep(1);
    setActiveConversation([]);
    
    // First message after 1 second
    setTimeout(() => {
      setActiveConversation([
        {
          agentName: "Product Research Agent",
          messageType: "request",
          content: "Task initiated: Analyze trending wireless earbuds market. Looking for products with high commission potential.",
          timestamp: new Date().toISOString()
        }
      ]);
      setVisualizationStep(2);
      
      // Second message after 2 more seconds
      setTimeout(() => {
        setActiveConversation(prev => [...prev, 
          {
            agentName: "SEO Optimization Agent",
            messageType: "response",
            content: "I'll analyze keywords for wireless earbuds. Starting search volume analysis and competition assessment.",
            timestamp: new Date().toISOString()
          }
        ]);
        setVisualizationStep(3);
        
        // Third message after 2 more seconds
        setTimeout(() => {
          setActiveConversation(prev => [...prev, 
            {
              agentName: "Content Creator Agent",
              messageType: "response",
              content: "Standing by for keyword data to begin content creation. Will prepare templates for product reviews and comparisons.",
              timestamp: new Date().toISOString()
            }
          ]);
          setVisualizationStep(4);
          
          // Complete the visualization after 2 more seconds
          setTimeout(() => {
            setActiveConversation(prev => [...prev, 
              {
                agentName: "SEO Optimization Agent",
                messageType: "request",
                content: "Keyword analysis complete. Top keywords: 'best noise cancelling wireless earbuds', 'wireless earbuds for running', 'long battery life wireless earbuds'. @Content Creator: Please use these in your drafts.",
                timestamp: new Date().toISOString()
              }
            ]);
            setVisualizationStep(5);
          }, 2000);
        }, 2000);
      }, 2000);
    }, 1000);
  };

  const exampleMessages: A2AMessage[] = [
    {
      agentName: "Product Research Agent",
      messageType: "request",
      content: "I've identified 'wireless earbuds' as a trending product category with high commission rates. Can you research the top 5 SEO keywords for this product?",
      timestamp: "2025-05-01T06:14:22.000Z"
    },
    {
      agentName: "SEO Optimization Agent",
      messageType: "response",
      content: "I've analyzed search volumes and competition for wireless earbuds. Here are the top 5 keywords:\n\n1. best wireless earbuds for running (3,400 monthly searches, low competition)\n2. noise cancelling wireless earbuds under $100 (4,200 monthly searches, medium competition)\n3. wireless earbuds for iphone (8,500 monthly searches, high competition)\n4. long battery life wireless earbuds (2,100 monthly searches, low competition)\n5. wireless earbuds with microphone for zoom calls (1,800 monthly searches, low competition)",
      timestamp: "2025-05-01T06:14:58.000Z"
    },
    {
      agentName: "Content Creator Agent",
      messageType: "request",
      content: "Can you generate a product comparison article outline using these keywords for wireless earbuds?",
      timestamp: "2025-05-01T06:15:32.000Z"
    }
  ];

  const agentCapabilities: AgentCapability[] = [
    {
      agentName: "Product Research Agent",
      capabilities: [
        "Identify trending products",
        "Analyze commission rates",
        "Calculate profitability scores",
        "Monitor price fluctuations",
        "Track product demand"
      ]
    },
    {
      agentName: "SEO Optimization Agent",
      capabilities: [
        "Keyword research and analysis",
        "Competition assessment",
        "Content optimization suggestions",
        "Search volume reporting",
        "Seasonality forecasting"
      ]
    },
    {
      agentName: "Content Creator Agent",
      capabilities: [
        "Product description generation",
        "Comparison article creation",
        "Review content writing",
        "Reader engagement optimization",
        "Call-to-action formulation"
      ]
    },
    {
      agentName: "Customer Behavior Analyst",
      capabilities: [
        "User journey mapping",
        "Conversion rate analysis",
        "Behavioral pattern recognition",
        "Audience segmentation",
        "A/B testing recommendations"
      ]
    }
  ];

  const collaborationFlow = `# A2A Collaboration Protocol

## Agent-to-Agent Message Format
{
  "sender": "agent_name",
  "receiver": "agent_name" | "all",
  "message_type": "request" | "response" | "broadcast",
  "content": "message_content",
  "context": {
    "task_id": "unique_identifier",
    "priority": 1-5,
    "references": ["reference_ids"]
  },
  "timestamp": "ISO_timestamp"
}

## Multi-Agent Workflow
1. Product Research Agent identifies profitable products
2. SEO Optimization Agent researches keywords for these products
3. Content Creator Agent generates optimized content
4. Customer Behavior Analyst provides conversion optimization tips
5. Social Media Strategy Agent creates promotion plan`;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
      <div className="border-b">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-2 flex items-center">
            <BrainCircuit className="mr-2 text-indigo-600" size={24} />
            A2A Collaboration Hub
          </h2>
          <p className="text-gray-600">
            Enable agent-to-agent communication using Google's A2A framework. This allows your specialized agents to work together, share insights, and create better results.
          </p>
          
          {visualizationStep > 0 && (
            <div className="mt-4 mb-6">
              <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg p-4 border border-indigo-100">
                <h3 className="text-sm font-semibold text-indigo-800 mb-2">Agent Collaboration Process</h3>
                <div className="relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 rounded">
                    <div 
                      className="absolute top-0 left-0 h-1 bg-indigo-600 rounded transition-all duration-500"
                      style={{ width: `${(visualizationStep / 5) * 100}%` }}
                    ></div>
                  </div>
                  <div className="pt-6 grid grid-cols-5 gap-1">
                    <div className={`text-center ${visualizationStep >= 1 ? 'text-indigo-700' : 'text-gray-400'}`}>
                      <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm mb-1 ${visualizationStep >= 1 ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-gray-100 border-2 border-gray-300'}`}>1</div>
                      <span className="text-xs">Initiate</span>
                    </div>
                    <div className={`text-center ${visualizationStep >= 2 ? 'text-indigo-700' : 'text-gray-400'}`}>
                      <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm mb-1 ${visualizationStep >= 2 ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-gray-100 border-2 border-gray-300'}`}>2</div>
                      <span className="text-xs">Research</span>
                    </div>
                    <div className={`text-center ${visualizationStep >= 3 ? 'text-indigo-700' : 'text-gray-400'}`}>
                      <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm mb-1 ${visualizationStep >= 3 ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-gray-100 border-2 border-gray-300'}`}>3</div>
                      <span className="text-xs">Analyze</span>
                    </div>
                    <div className={`text-center ${visualizationStep >= 4 ? 'text-indigo-700' : 'text-gray-400'}`}>
                      <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm mb-1 ${visualizationStep >= 4 ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-gray-100 border-2 border-gray-300'}`}>4</div>
                      <span className="text-xs">Create</span>
                    </div>
                    <div className={`text-center ${visualizationStep >= 5 ? 'text-indigo-700' : 'text-gray-400'}`}>
                      <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm mb-1 ${visualizationStep >= 5 ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-gray-100 border-2 border-gray-300'}`}>5</div>
                      <span className="text-xs">Complete</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 border rounded-lg p-3 bg-gray-50 max-h-80 overflow-y-auto">
                {activeConversation.map((msg, idx) => (
                  <div 
                    key={idx}
                    className={`mb-3 last:mb-0 p-3 rounded-lg ${
                      msg.messageType === 'request' 
                        ? 'bg-blue-50 border border-blue-100'
                        : 'bg-green-50 border border-green-100'
                    } animate-fade-in-up`}
                    style={{ animationDelay: `${idx * 0.2}s` }}
                  >
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span className="font-medium">{msg.agentName}</span>
                      <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-sm whitespace-pre-wrap">
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border rounded-lg p-4 bg-gray-50">
              <h3 className="font-medium mb-3 flex items-center">
                <Zap size={16} className="text-blue-600 mr-2" />
                Agent Capabilities
              </h3>
              <div className="space-y-4 max-h-64 overflow-y-auto pr-2">
                {agentCapabilities.map((agent) => (
                  <div key={agent.agentName} className="border-b pb-3 last:border-0 last:pb-0">
                    <p className="font-medium text-sm">{agent.agentName}</p>
                    <ul className="mt-1 space-y-1">
                      {agent.capabilities.map((cap, idx) => (
                        <li key={idx} className="text-xs text-gray-600 flex items-start">
                          <Check size={12} className="text-green-600 mr-1 mt-0.5" />
                          {cap}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="font-medium mb-3">A2A Collaboration Protocol</h3>
              
              <div className="bg-gray-100 rounded p-2 text-xs font-mono text-gray-800 max-h-64 overflow-y-auto">
                <pre>{collaborationFlow}</pre>
              </div>
              
              <div className="mt-3 flex justify-end">
                <button
                  onClick={() => copyToClipboard(collaborationFlow, 'protocol')}
                  className="text-sm flex items-center text-blue-600 hover:text-blue-800"
                >
                  {copied === 'protocol' ? (
                    <>
                      <Check size={14} className="mr-1" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={14} className="mr-1" />
                      Copy Protocol
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium">Example A2A Conversation</h3>
              <button
                onClick={() => setShowExample(!showExample)}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                {showExample ? 'Hide Example' : 'Show Example'}
              </button>
            </div>
            
            {showExample && (
              <div className="border rounded-lg p-3 bg-gray-50 max-h-80 overflow-y-auto">
                {exampleMessages.map((msg, idx) => (
                  <div 
                    key={idx}
                    className={`mb-3 last:mb-0 p-3 rounded-lg ${
                      msg.messageType === 'request' 
                        ? 'bg-blue-50 border border-blue-100'
                        : 'bg-green-50 border border-green-100'
                    }`}
                  >
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span className="font-medium">{msg.agentName}</span>
                      <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-sm whitespace-pre-wrap">
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="mt-6 flex flex-col md:flex-row gap-4">
            <button
              onClick={startVisualization}
              disabled={isLoading || visualizationStep > 0}
              className={`flex-1 py-3 rounded-lg font-medium flex items-center justify-center transition-all duration-200 shadow-sm ${
                isLoading || visualizationStep > 0
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white hover:shadow'
              }`}
            >
              {visualizationStep > 0 ? (
                <>
                  <ChartBar size={18} className="mr-2" />
                  Visualization In Progress...
                </>
              ) : (
                <>
                  <MessageSquare size={18} className="mr-2" />
                  Visualize Agent Collaboration
                </>
              )}
            </button>
            
            <button
              onClick={onRunCollaboration}
              disabled={isLoading}
              className={`flex-1 py-3 rounded-lg font-medium flex items-center justify-center transition-all duration-200 shadow-sm ${
                isLoading 
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow'
              }`}
            >
              {isLoading ? (
                <>
                  <RefreshCw size={18} className="mr-2 animate-spin" />
                  Running Collaboration...
                </>
              ) : (
                <>
                  <ArrowRight size={18} className="mr-2" />
                  Start Live Collaboration
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
