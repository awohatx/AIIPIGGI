import { ExternalLink, Star } from 'lucide-react';

interface ProductProps {
  product: {
    id: number;
    title: string;
    description: string;
    price: number;
    image: string;
    rating: number;
    category: string;
    affiliateUrl: string;
    commission: number;
  };
}

export default function ProductCard({ product }: ProductProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden transition-all duration-300 hover:shadow-md hover:translate-y-[-2px] group">
      <div className="h-48 overflow-hidden relative">
        <img 
          src={product.image} 
          alt={product.title}
          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center shadow-sm">
          <Star size={14} className="text-amber-500" fill="currentColor" />
          <span className="ml-1 text-xs font-medium text-gray-700">{product.rating}</span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center mb-2">
          <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full capitalize">
            {product.category}
          </span>
          <span className="ml-2 text-xs text-green-600 font-medium">{product.commission}% commission</span>
        </div>
        <h3 className="font-semibold text-lg text-gray-800 line-clamp-1 group-hover:text-indigo-600 transition-colors duration-200">{product.title}</h3>
        <p className="text-gray-600 text-sm mt-1 line-clamp-2">{product.description}</p>
        <div className="mt-3 flex items-center justify-between">
          <span className="font-bold text-lg">${product.price.toFixed(2)}</span>
          <a 
            href={product.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 px-3 py-1.5 rounded-md bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-700 transition-colors duration-200"
          >
            <span>View</span>
            <ExternalLink size={14} />
          </a>
        </div>
      </div>
    </div>
  );
}
