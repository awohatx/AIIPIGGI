import { useState, useEffect } from 'react';
import { Activity, ArrowRight, ChevronsRight, Code, Cpu, Database, Mail, MessageSquare, RefreshCw, Server, User } from 'lucide-react';

interface ActorMessage {
  sender: string;
  receiver: string;
  content: string;
  timestamp: string;
}

interface Actor {
  id: string;
  name: string;
  type: string;
  inbox: ActorMessage[];
  state: Record<string, any>;
}

export default function ActorModelDemo() {
  const [logs, setLogs] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  
  // Simplified actor model demonstration
  const [actors, setActors] = useState<Actor[]>([
    {
      id: 'product-research',
      name: 'Product Research Agent',
      type: 'research',
      inbox: [],
      state: { products: [], searchTerms: [] }
    },
    {
      id: 'seo-optimizer',
      name: 'SEO Optimization Agent',
      type: 'optimization',
      inbox: [],
      state: { keywords: [], suggestions: [] }
    },
    {
      id: 'content-creator',
      name: 'Content Creator Agent', 
      type: 'content',
      inbox: [],
      state: { articles: [], drafts: [] }
    }
  ]);

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  const clearLogs = () => {
    setLogs([]);
  };

  const sendMessage = (from: string, to: string, content: string) => {
    const message: ActorMessage = {
      sender: from,
      receiver: to,
      content,
      timestamp: new Date().toISOString()
    };
    
    addLog(`${from} sends message to ${to}: "${content}"`);
    
    setActors(prev => prev.map(actor => {
      if (actor.id === to) {
        return {
          ...actor,
          inbox: [...actor.inbox, message]
        };
      }
      return actor;
    }));
  };
  
  const processMessage = (actorId: string) => {
    setActors(prev => {
      const actorIndex = prev.findIndex(a => a.id === actorId);
      if (actorIndex === -1 || prev[actorIndex].inbox.length === 0) return prev;
      
      const actor = prev[actorIndex];
      const message = actor.inbox[0];
      const newInbox = actor.inbox.slice(1);
      
      addLog(`${actor.name} processing message: "${message.content}"`);
      
      let newState = { ...actor.state };
      let response: string | null = null;
      
      // Actor-specific message handling
      if (actor.type === 'research' && message.content.includes('find products')) {
        newState.searchTerms = ['wireless earbuds', 'smartwatches', 'fitness trackers'];
        newState.products = ['Echo Buds', 'Galaxy Watch', 'Fitbit Charge'];
        response = 'Found 3 profitable products in trending categories';
      }
      else if (actor.type === 'optimization' && message.content.includes('analyze keywords')) {
        newState.keywords = ['best wireless earbuds', 'top fitness trackers 2025', 'smartwatch comparison'];
        newState.suggestions = ['Add H1 tag for "Best Wireless Earbuds"', 'Create FAQ section for common questions'];
        response = 'Completed keyword analysis with 3 primary keywords and 2 optimization suggestions';
      }
      else if (actor.type === 'content' && message.content.includes('create article')) {
        newState.drafts = ['Why Wireless Earbuds Are Essential in 2025'];
        newState.articles = ['The Ultimate Guide to Choosing Wireless Earbuds'];
        response = 'Created article draft with SEO optimization';
      }
      
      // Send response if needed
      if (response && message.sender) {
        setTimeout(() => {
          sendMessage(actorId, message.sender, response!);
        }, 1000);
      }
      
      // Update actor state
      const updatedActors = [...prev];
      updatedActors[actorIndex] = {
        ...actor,
        inbox: newInbox,
        state: newState
      };
      
      return updatedActors;
    });
  };
  
  // Visualization state
  const [activeMessage, setActiveMessage] = useState<{from: string, to: string, content: string} | null>(null);
  const [highlightedActor, setHighlightedActor] = useState<string | null>(null);
  
  // Clear visualization effects
  useEffect(() => {
    if (activeMessage) {
      const timer = setTimeout(() => {
        setActiveMessage(null);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [activeMessage]);
  
  useEffect(() => {
    if (highlightedActor) {
      const timer = setTimeout(() => {
        setHighlightedActor(null);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [highlightedActor]);

  const runDemonstration = async () => {
    setIsProcessing(true);
    clearLogs();
    setCurrentStep(0);
    
    // Reset actor state
    setActors(actors.map(actor => ({
      ...actor,
      inbox: [],
      state: actor.type === 'research' 
        ? { products: [], searchTerms: [] }
        : actor.type === 'optimization'
          ? { keywords: [], suggestions: [] }
          : { articles: [], drafts: [] }
    })));
    
    // Step 1: Initial message to product research
    addLog('Starting actor-based agent collaboration...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setActiveMessage({from: 'user', to: 'product-research', content: 'Please find products related to audio devices'});
    sendMessage('user', 'product-research', 'Please find products related to audio devices');
    setCurrentStep(1);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Step 2: Process message
    setHighlightedActor('product-research');
    processMessage('product-research');
    setCurrentStep(2);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Step 3: Research agent sends message to SEO agent
    setActiveMessage({from: 'product-research', to: 'seo-optimizer', content: 'Please analyze keywords for wireless earbuds'});
    sendMessage('product-research', 'seo-optimizer', 'Please analyze keywords for wireless earbuds');
    setCurrentStep(3);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Step 4: Process SEO agent message
    setHighlightedActor('seo-optimizer');
    processMessage('seo-optimizer');
    setCurrentStep(4);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Step 5: SEO agent sends message to content creator
    setActiveMessage({from: 'seo-optimizer', to: 'content-creator', content: 'Please create article about wireless earbuds using these keywords'});
    sendMessage('seo-optimizer', 'content-creator', 'Please create article about wireless earbuds using these keywords');
    setCurrentStep(5);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Step 6: Process content creator message
    setHighlightedActor('content-creator');
    processMessage('content-creator');
    setCurrentStep(6);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Step 7: Final message back to user
    setActiveMessage({from: 'content-creator', to: 'user', content: 'Completed article creation with SEO optimization'});
    sendMessage('content-creator', 'user', 'Completed article creation with SEO optimization');
    setCurrentStep(7);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    addLog('Actor-based collaboration demonstration completed');
    setIsProcessing(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
      <div className="border-b">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-2">Actor Model Integration</h2>
          <p className="text-gray-600">
            This demonstration shows how we could integrate the Actor Model pattern from actor-core to enhance our agent collaboration system with more robust state management and message passing.
          </p>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="col-span-1 bg-gray-50 rounded-lg p-4 border">
              <h3 className="font-medium mb-3 flex items-center">
                <Server size={16} className="text-indigo-600 mr-2" />
                Actor System
              </h3>
              <div className="relative space-y-4">
                {/* Message visualization */}
                {activeMessage && (
                  <div className="absolute inset-0 z-10 pointer-events-none">
                    <div className="flex items-center justify-center h-full">
                      <div className="animate-pulse-light flex items-center bg-blue-100 text-blue-800 px-3 py-2 rounded-lg shadow-sm">
                        <Mail className="mr-2" size={16} />
                        <span className="text-sm font-medium">{activeMessage.content.substring(0, 20)}...</span>
                        <ChevronsRight className="mx-2" size={16} />
                        <span className="text-xs font-bold bg-blue-200 px-2 py-1 rounded">
                          {activeMessage.to}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                
                {actors.map((actor) => (
                  <div 
                    key={actor.id} 
                    className={`p-3 rounded-md border shadow-sm transition-all duration-300 ${
                      highlightedActor === actor.id 
                        ? 'bg-blue-50 border-blue-300' 
                        : 'bg-white'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium text-sm flex items-center">
                        {actor.type === 'research' ? (
                          <Database size={14} className="mr-1 text-orange-500" />
                        ) : actor.type === 'optimization' ? (
                          <Cpu size={14} className="mr-1 text-blue-500" />
                        ) : (
                          <MessageSquare size={14} className="mr-1 text-green-500" />
                        )}
                        {actor.name}
                      </h4>
                      <div className="flex items-center space-x-2">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          actor.type === 'research' 
                            ? 'bg-orange-50 text-orange-700' 
                            : actor.type === 'optimization'
                              ? 'bg-blue-50 text-blue-700'
                              : 'bg-green-50 text-green-700'
                        }`}>
                          {actor.type}
                        </span>
                        <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full">
                          {actor.inbox.length} messages
                        </span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-600">
                      <div className="mb-1 flex items-center">
                        <User size={12} className="mr-1" />
                        <span className="font-medium">ID:</span> 
                        <code className="ml-1 px-1 bg-gray-100 rounded">{actor.id}</code>
                      </div>
                      <div>
                        <span className="font-medium">State:</span>
                        <pre className={`mt-1 p-1 rounded overflow-x-auto text-xs transition-colors duration-300 ${
                          highlightedActor === actor.id ? 'bg-blue-100' : 'bg-gray-50'
                        }`}>
                          {JSON.stringify(actor.state, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="col-span-2 bg-gray-50 rounded-lg p-4 border">
              <h3 className="font-medium mb-3 flex items-center">
                <Activity size={16} className="text-green-600 mr-2" />
                Actor Communication Flow
              </h3>
              <div className="bg-gray-800 text-gray-200 p-3 rounded-md h-64 overflow-y-auto font-mono text-xs">
                {logs.length > 0 ? (
                  logs.map((log, index) => (
                    <div key={index} className="pb-1">{log}</div>
                  ))
                ) : (
                  <div className="text-gray-400 italic">Click "Run Demonstration" to see actor communication...</div>
                )}
              </div>
              <div className="mt-4 flex justify-between items-center">
                <button
                  onClick={clearLogs}
                  className="text-gray-600 hover:text-gray-800 text-sm"
                >
                  Clear Logs
                </button>
                <button
                  onClick={runDemonstration}
                  disabled={isProcessing}
                  className={`py-2 px-4 rounded-md font-medium flex items-center transition-all duration-200 ${
                    isProcessing 
                      ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow'
                  }`}
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw size={16} className="mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <ArrowRight size={16} className="mr-2" />
                      Run Demonstration
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-6 bg-blue-50 border border-blue-100 rounded-lg p-4">
            <h3 className="font-medium mb-2 text-blue-800">Actor Model vs. A2A Framework</h3>
            <div className="text-sm text-blue-700">
              <p className="mb-2">
                The Actor Model provides a mathematical foundation for building concurrent systems,
                whereas Google's A2A focuses on the communication protocol between agents. 
                Here's how they compare:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                <div>
                  <h4 className="font-medium mb-1">Actor Model Strengths:</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Strong isolation of actor state</li>
                    <li>Built-in concurrency management</li>
                    <li>Hierarchical supervision strategies</li>
                    <li>Location transparency</li>
                    <li>Fault tolerance through isolation</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-1">A2A Framework Strengths:</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Standardized communication protocols</li>
                    <li>Focus on LLM-specific interactions</li>
                    <li>Context sharing mechanisms</li>
                    <li>Built-in task management</li>
                    <li>Emphasis on collaboration patterns</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-3 flex justify-end">
              <a 
                href="https://github.com/rivet-gg/actor-core"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                <Code size={14} className="mr-1" />
                View actor-core on GitHub
              </a>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="font-medium mb-3">Integration Possibilities</h3>
            <p className="text-sm text-gray-600">
              We could enhance AffiliAgent Hub by combining actor-core with our existing A2A implementation:
            </p>
            <ul className="mt-2 space-y-2 text-sm text-gray-600">
              <li className="flex items-start">
                <MessageSquare size={16} className="text-indigo-600 mr-2 mt-0.5" />
                <span>Use actor-core for internal state management of each agent</span>
              </li>
              <li className="flex items-start">
                <MessageSquare size={16} className="text-indigo-600 mr-2 mt-0.5" />
                <span>Maintain A2A protocol for standardized agent communication</span>
              </li>
              <li className="flex items-start">
                <MessageSquare size={16} className="text-indigo-600 mr-2 mt-0.5" />
                <span>Leverage actor supervision for better error handling in agent system</span>
              </li>
              <li className="flex items-start">
                <MessageSquare size={16} className="text-indigo-600 mr-2 mt-0.5" />
                <span>Create a hierarchy of specialized agents with supervisor agents</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
