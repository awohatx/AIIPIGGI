import { Brain, Layers, Lightbulb, TrendingUp, Users, Zap } from 'lucide-react';

export default function Features() {
  const featureCards = [
    {
      icon: <Brain className="w-8 h-8 text-purple-600" />,
      title: "Collaborative AI Agents",
      description: "Unlike traditional affiliate platforms that offer basic tools, our specialized AI agents work together to optimize every aspect of your affiliate business - from product research to content creation and SEO.",
      highlight: "Traditional platforms provide only basic tools, while we provide AI-powered specialists that collaborate."
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-blue-600" />,
      title: "Intelligent Market Analysis",
      description: "Our agents continuously monitor market trends, competition, and consumer behavior to identify high-potential products with optimal commission structures.",
      highlight: "Move beyond static product lists to dynamic, data-driven product selection."
    },
    {
      icon: <Zap className="w-8 h-8 text-yellow-600" />,
      title: "Accelerated Content Production",
      description: "Generate high-quality, SEO-optimized product descriptions and reviews in minutes instead of hours. Our Content Creator Agent balances persuasive writing with authenticity.",
      highlight: "Transform from struggling with content creation to producing converting content at scale."
    },
    {
      icon: <Layers className="w-8 h-8 text-green-600" />,
      title: "Multi-dimension Optimization",
      description: "Simultaneously optimize all aspects of your affiliate business - from product selection to content creation, SEO, and conversion strategies.",
      highlight: "Replace disjointed tools with an integrated ecosystem of specialized agents."
    },
    {
      icon: <Users className="w-8 h-8 text-rose-600" />,
      title: "Evolving Intelligence",
      description: "Our agent system learns from your results and adapts strategies over time, continuously improving performance across all marketing channels.",
      highlight: "Static strategies become dynamic, evolving approaches that improve with experience."
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-amber-600" />,
      title: "Prompt Engineering Simplified",
      description: "Leverage pre-engineered expert prompts designed specifically for affiliate marketing, eliminating the need to become a prompt engineering expert yourself.",
      highlight: "No more struggling with generic AI tools - use prompts crafted by affiliate marketing experts."
    }
  ];

  return (
    <div>
      <div className="mb-8 text-center max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          What Sets AffiliAgent Hub Apart
        </h1>
        <p className="text-gray-600">
          In the crowded world of affiliate marketing tools, AffiliAgent Hub stands out by providing
          a collaborative ecosystem of specialized AI agents that work together to maximize your Amazon affiliate earnings.
        </p>
      </div>

      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-8 mb-10 shadow-sm border border-indigo-100/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-semibold mb-6 text-center" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            The Traditional Approach vs. AffiliAgent Hub
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="font-semibold mb-3 text-gray-700">Traditional Affiliate Marketing</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-600 text-sm">Manual product research without market data</span>
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-600 text-sm">Generic content creation with minimal optimization</span>
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-600 text-sm">Basic SEO tools without strategic guidance</span>
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-600 text-sm">Limited analytics focused on clicks, not behavior</span>
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-600 text-sm">Disconnected tools requiring manual coordination</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl p-6 shadow-sm text-white">
              <h3 className="font-semibold mb-3">AffiliAgent Hub Approach</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="text-yellow-300 mr-2">•</span>
                  <span className="text-sm">AI-powered product research with profitability analysis</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-300 mr-2">•</span>
                  <span className="text-sm">Specialized content agents creating conversion-focused material</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-300 mr-2">•</span>
                  <span className="text-sm">Strategic SEO optimization with keyword research built-in</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-300 mr-2">•</span>
                  <span className="text-sm">Behavioral analysis for understanding customer journey</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-300 mr-2">•</span>
                  <span className="text-sm">Collaborative agent ecosystem with unified strategy</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {featureCards.map((feature, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-200">
            <div className="bg-gray-50 p-3 rounded-full w-fit mb-4">
              {feature.icon}
            </div>
            <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
            <p className="text-gray-600 text-sm mb-4">{feature.description}</p>
            <div className="border-t pt-3">
              <p className="text-sm font-medium text-blue-700">
                <span className="font-bold">Difference:</span> {feature.highlight}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 rounded-xl p-8 shadow-sm">
        <h2 className="text-2xl font-semibold mb-4 text-center" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          Ready to Transform Your Affiliate Marketing?
        </h2>
        <p className="text-center text-gray-600 max-w-2xl mx-auto mb-6">
          Experience the power of collaborative AI agents working together to maximize your Amazon affiliate earnings.
        </p>
        <div className="flex flex-col items-center space-y-4">
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow">
            Get Started with AffiliAgent Hub
          </button>
          <a 
            href="/backend-info" 
            className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
          >
            Learn about our backend infrastructure
          </a>
        </div>
      </div>
    </div>
  );
}
