import { useState } from 'react';
import { ChevronDown, ChevronUp, Code, Copy, Download, GitBranch, MessageCircle, Settings, Users, Zap } from 'lucide-react';
import { simulateA2ACollaboration } from '../utils/a2aUtils';
import A2ACollaboration from '../components/A2ACollaboration';
import ActorModelDemo from '../components/ActorModelDemo';
import { agentPrompts } from '../data/mockData';
import { productResearchAgentCode, amazonApiDocumentation } from '../data/pythonCodeSnippets';
import SEOAgentConfig, { SEOAgentConfig as SEOConfig } from '../components/SEOAgentConfig';
import CodeDisplay from '../components/CodeDisplay';

export default function AgentHub() {
  const [expandedPrompt, setExpandedPrompt] = useState<number | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [showSEOConfig, setShowSEOConfig] = useState(false);
  const [showPythonCode, setShowPythonCode] = useState(false);
  const [showA2A, setShowA2A] = useState(false);
  const [showActorModel, setShowActorModel] = useState(false);
  const [isCollaborating, setIsCollaborating] = useState(false);
  const [collaborationResult, setCollaborationResult] = useState<any>(null);
  const [seoConfig, setSeoConfig] = useState<SEOConfig>({
    productCategories: [],
    detailLevel: 'concise',
    preferredTools: [],
    focusAreas: []
  });
  const [customSEOPrompt, setCustomSEOPrompt] = useState('');

  const copyToClipboard = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const togglePrompt = (id: number) => {
    if (expandedPrompt === id) {
      setExpandedPrompt(null);
    } else {
      setExpandedPrompt(id);
    }
  };
  
  const handleRunCollaboration = async () => {
    setIsCollaborating(true);
    try {
      const result = await simulateA2ACollaboration(
        "Product Research Agent",
        "Identify profitable wireless earbuds and optimize content for affiliate marketing",
        ["SEO Optimization Agent", "Content Creator Agent", "Customer Behavior Analyst"]
      );
      setCollaborationResult(result);
    } catch (error) {
      console.error("Collaboration error:", error);
    } finally {
      setIsCollaborating(false);
    }
  };

  const handleSaveSEOConfig = (config: SEOConfig) => {
    setSeoConfig(config);
    setShowSEOConfig(false);
    
    // Generate a custom prompt based on the configuration
    let prompt = `You are an SEO Optimization Agent specializing in Amazon affiliate marketing. Your goal is to maximize organic traffic and conversion rates through strategic keyword optimization.`;
    
    if (config.productCategories.length > 0) {
      prompt += `\n\nFocus on the following product categories: ${config.productCategories.join(', ')}.`;
    } else {
      prompt += `\n\nProvide general SEO recommendations across various Amazon product categories.`;
    }
    
    prompt += `\n\nProvide ${config.detailLevel === 'concise' ? 'concise and actionable' : 'detailed and comprehensive'} analysis and recommendations.`;
    
    if (config.preferredTools.length > 0) {
      prompt += `\n\nUtilize the following tools for research and analysis: ${config.preferredTools.join(', ')}.`;
    }
    
    if (config.focusAreas.length > 0) {
      prompt += `\n\nSpecifically focus on: ${config.focusAreas.join(', ')}.`;
    }
    
    prompt += `\n\nTASK:
1. Research high-value keywords related to specific products with:
   - Monthly search volume data
   - Competition analysis
   - Buyer intent assessment
2. Analyze existing content and provide optimization recommendations:
   - Title improvements
   - Meta description enhancements
   - Heading structure optimization
   - Image alt text suggestions
   - Internal linking opportunities
3. Identify content gaps that should be addressed
4. Suggest topic clusters around main product categories
5. Provide a comprehensive SEO strategy with:
   - Primary and secondary keywords for each page
   - Content calendar recommendations
   - Performance tracking metrics

Focus on long-tail keywords with buyer intent and include recommendations for schema markup where applicable. Prioritize user experience while optimizing for search engines.`;
    
    setCustomSEOPrompt(prompt);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          Agent Hub
        </h1>
        <p className="text-gray-600 mt-1">Collaborate with specialized AI agents to optimize your affiliate store</p>
      </div>

      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border rounded-lg p-4">
            <div className="bg-blue-100 text-blue-800 rounded-full w-8 h-8 flex items-center justify-center mb-3 font-bold">1</div>
            <h3 className="font-semibold mb-2">Select an Agent</h3>
            <p className="text-gray-600 text-sm">Choose a specialized agent based on the task you need to accomplish.</p>
          </div>
          <div className="border rounded-lg p-4">
            <div className="bg-blue-100 text-blue-800 rounded-full w-8 h-8 flex items-center justify-center mb-3 font-bold">2</div>
            <h3 className="font-semibold mb-2">Copy the Prompt</h3>
            <p className="text-gray-600 text-sm">Copy the specialized prompt designed for optimal agent performance.</p>
          </div>
          <div className="border rounded-lg p-4">
            <div className="bg-blue-100 text-blue-800 rounded-full w-8 h-8 flex items-center justify-center mb-3 font-bold">3</div>
            <h3 className="font-semibold mb-2">Paste in ChatGPT</h3>
            <p className="text-gray-600 text-sm">Paste the prompt into ChatGPT and start collaborating with your agent.</p>
          </div>
        </div>
      </div>

      {showSEOConfig ? (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4">Configure SEO Optimization Agent</h3>
          <SEOAgentConfig onSave={handleSaveSEOConfig} defaultConfig={seoConfig} />
        </div>
      ) : showA2A ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">A2A Collaboration (Google)</h3>
            <button 
              onClick={() => setShowA2A(false)}
              className="text-gray-600 hover:text-gray-800 text-sm font-medium"
            >
              Back to Agents
            </button>
          </div>
          
          <p className="text-gray-600">
            Leverage Google's A2A (Agent-to-Agent) framework to enable collaboration between specialized agents. This advanced protocol allows agents to share information, delegate tasks, and jointly solve complex problems.
          </p>
          
          <A2ACollaboration 
            onRunCollaboration={handleRunCollaboration}
            isLoading={isCollaborating}
          />
          
          {collaborationResult && (
            <div className="bg-white rounded-lg shadow p-6 mt-4">
              <h3 className="font-semibold mb-4">Collaboration Results</h3>
              <div className="mb-3">
                <span className="font-medium">Task:</span> 
                <span className="ml-2">{collaborationResult.taskId}</span>
              </div>
              <div className="mb-3">
                <span className="font-medium">Duration:</span> 
                <span className="ml-2">{Math.round((new Date(collaborationResult.endTime).getTime() - new Date(collaborationResult.startTime).getTime()) / 1000)} seconds</span>
              </div>
              <div className="mb-3">
                <span className="font-medium">Agents Involved:</span> 
                <span className="ml-2">{collaborationResult.agentsInvolved.join(", ")}</span>
              </div>
              <div>
                <span className="font-medium">Outcome:</span>
                <p className="mt-1 text-sm">{collaborationResult.outcome}</p>
              </div>
            </div>
          )}
        </div>
      ) : showActorModel ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Actor Model Integration Demo</h3>
            <button 
              onClick={() => setShowActorModel(false)}
              className="text-gray-600 hover:text-gray-800 text-sm font-medium"
            >
              Back to Agents
            </button>
          </div>
          
          <p className="text-gray-600">
            Explore how the Actor Model pattern from actor-core can be integrated with our A2A framework to create a more robust agent collaboration system.
          </p>
          
          <ActorModelDemo />
        </div>
      ) : showPythonCode ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Product Research Agent - Python Implementation</h3>
            <button 
              onClick={() => setShowPythonCode(false)}
              className="text-gray-600 hover:text-gray-800 text-sm font-medium"
            >
              Back to Agents
            </button>
          </div>
          
          <p className="text-gray-600">
            This Python script uses Amazon's Product Advertising API to find profitable products for affiliate marketing.
            It analyzes products based on price, reviews, ratings, and estimated commission to identify the best opportunities.
          </p>
          
          <CodeDisplay 
            code={productResearchAgentCode}
            language="python"
            title="product_research_agent.py"
            description="Fully functional Amazon Product Research Agent implementation"
          />
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
            <h4 className="font-medium text-blue-800 mb-2">Implementation Guide</h4>
            <p className="text-blue-700 text-sm">{amazonApiDocumentation}</p>
            <div className="mt-3 flex justify-end">
              <button 
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
                onClick={() => {
                  const blob = new Blob([productResearchAgentCode], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'product_research_agent.py';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                }}
              >
                <Download size={16} />
                <span>Download Script</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {agentPrompts.map((agent) => (
            <div key={agent.id} className="bg-white rounded-lg shadow overflow-hidden">
            <div 
              className="p-4 flex justify-between items-center cursor-pointer hover:bg-gray-50"
              onClick={() => togglePrompt(agent.id)}
            >
              <div>
                <h3 className="font-semibold text-lg">{agent.role}</h3>
                <p className="text-gray-600 text-sm">{agent.description}</p>
              </div>
              <div className="flex items-center">
                <button 
                  className="p-2 rounded-full hover:bg-blue-50 mr-2 transition-colors duration-200"
                  onClick={(e) => {
                    e.stopPropagation();
                    copyToClipboard(agent.prompt, agent.id);
                  }}
                >
                  <Copy size={18} className={`${copiedId === agent.id ? 'text-green-600' : 'text-gray-600'}`} />
                </button>
                {expandedPrompt === agent.id ? 
                  <ChevronUp size={20} className="text-gray-600" /> : 
                  <ChevronDown size={20} className="text-gray-600" />
                }
              </div>
            </div>
            {expandedPrompt === agent.id && (
              <div className="p-4 bg-gray-50 border-t">
                <h4 className="font-medium mb-2">Prompt to copy:</h4>
                <div className="bg-white p-3 rounded border overflow-auto max-h-64 text-sm font-mono">
                  {agent.id === 3 && customSEOPrompt ? 
                    customSEOPrompt.split('\n').map((line, i) => (
                      <div key={i} className={line.startsWith('TASK:') ? 'font-semibold mt-2' : ''}>
                        {line || <br />}
                      </div>
                    ))
                    :
                    agent.prompt.split('\n').map((line, i) => (
                      <div key={i} className={line.startsWith('TASK:') ? 'font-semibold mt-2' : ''}>
                        {line || <br />}
                      </div>
                    ))
                  }
                </div>
                <div className="mt-3 flex justify-end space-x-2">
                  {agent.id === 3 && (
                    <button 
                      className="flex items-center border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 px-4 py-2 rounded text-sm font-medium transition-colors duration-200"
                      onClick={() => setShowSEOConfig(true)}
                    >
                      <Settings size={16} className="mr-2" />
                      Configure
                    </button>
                  )}
                  <button 
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm font-medium transition-colors duration-200"
                    onClick={() => copyToClipboard(agent.id === 3 && customSEOPrompt ? customSEOPrompt : agent.prompt, agent.id)}
                  >
                    {copiedId === agent.id ? 'Copied!' : 'Copy Prompt'}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="bg-white rounded-lg shadow overflow-hidden border-2 border-blue-100 border-dashed">
              <div 
                className="p-4 flex justify-between items-center cursor-pointer hover:bg-blue-50 transition-colors duration-200"
                onClick={() => setShowPythonCode(true)}
              >
                <div>
                  <h3 className="font-semibold text-lg text-blue-700">Product Research Agent - Python Implementation</h3>
                  <p className="text-gray-600 text-sm">Working Python code for Amazon product research using the Product Advertising API</p>
                </div>
                <div className="flex items-center">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">New</span>
                  <Code size={18} className="text-blue-600" />
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow overflow-hidden border-2 border-purple-100 border-dashed">
              <div 
                className="p-4 flex justify-between items-center cursor-pointer hover:bg-purple-50 transition-colors duration-200"
                onClick={() => setShowA2A(true)}
              >
                <div>
                  <h3 className="font-semibold text-lg text-purple-700">A2A Collaboration Framework</h3>
                  <p className="text-gray-600 text-sm">Google's Agent-to-Agent protocol for advanced agent collaboration</p>
                </div>
                <div className="flex items-center">
                  <span className="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">Featured</span>
                  <Users size={18} className="text-purple-600" />
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 bg-white rounded-lg shadow overflow-hidden border-2 border-green-100 border-dashed">
            <div 
              className="p-4 flex justify-between items-center cursor-pointer hover:bg-green-50 transition-colors duration-200"
              onClick={() => setShowActorModel(true)}
            >
              <div>
                <h3 className="font-semibold text-lg text-green-700">Actor Model Integration (actor-core)</h3>
                <p className="text-gray-600 text-sm">Enhanced agent state management and communication using the Actor Model pattern</p>
              </div>
              <div className="flex items-center">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">Experimental</span>
                <GitBranch size={18} className="text-green-600" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
