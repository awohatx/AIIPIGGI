import { useState, useEffect } from 'react';
import { ChartBar, DollarSign, Lightbulb, ShoppingBag, TrendingUp } from 'lucide-react';
import StatCard from '../components/StatCard';

export default function Dashboard() {
  const [stats, setStats] = useState({
    sales: 0,
    products: 0,
    revenue: 0,
    conversion: 0
  });

  useEffect(() => {
    // Mock data - would come from API in real implementation
    setStats({
      sales: 124,
      products: 48,
      revenue: 2456.78,
      conversion: 3.2
    });
  }, []);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          Dashboard
        </h1>
        <p className="text-gray-600 mt-1">Welcome to your Amazon Affiliate store</p>
      </div>

      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 mb-8 shadow-sm border border-indigo-100">
        <div className="flex flex-col md:flex-row items-center">
          <div className="mb-4 md:mb-0 md:mr-6">
            <img 
              src="https://images.unsplash.com/photo-1589149098258-3b71a54749a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1400&q=80" 
              alt="AI Collaboration" 
              className="w-24 h-24 object-cover rounded-full border-4 border-white shadow-sm"
            />
          </div>
          <div>
            <h2 className="text-xl font-semibold mb-2" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              The Power of AI Collaboration
            </h2>
            <p className="text-gray-700">
              AffiliAgent Hub is revolutionizing affiliate marketing by combining specialized AI agents that work together 
              to maximize your earnings. Unlike traditional platforms, our collaborative agent system handles everything 
              from product research to content creation and SEO optimization.
            </p>
            <div className="mt-3">
              <a 
                href="/features" 
                className="text-blue-600 font-medium hover:text-blue-800 flex items-center"
              >
                See what sets us apart <Lightbulb className="ml-1 w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Sales" 
          value={stats.sales} 
          icon={<ChartBar className="text-blue-600" />} 
          trend="+12%" 
        />
        <StatCard 
          title="Active Products" 
          value={stats.products} 
          icon={<ShoppingBag className="text-green-600" />} 
          trend="+3" 
        />
        <StatCard 
          title="Revenue" 
          value={`$${stats.revenue.toFixed(2)}`} 
          icon={<DollarSign className="text-yellow-600" />} 
          trend="+8.1%" 
        />
        <StatCard 
          title="Conversion Rate" 
          value={`${stats.conversion}%`} 
          icon={<TrendingUp className="text-purple-600" />} 
          trend="+0.6%" 
        />
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Agent Activity</h2>
        <div className="border rounded-lg p-8 text-center">
          <p className="text-gray-500">
            Connect with your specialized agents in the Agent Hub to see activity.
          </p>
          <button 
            className="mt-4 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded font-medium transition-colors duration-200"
            onClick={() => window.location.href = '/agents'}
          >
            Go to Agent Hub
          </button>
        </div>
      </div>
    </div>
  );
}
